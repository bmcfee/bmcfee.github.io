function r = regularizeNone(W, X, gradient)
%
%   r = regularizeNone(W, X, gradient)
%   
%   Always returns 0

    r = 0;
end
