function r = regularizeKernelDiag(W, X, gradient)
%
% r = regularizeKernelDiag(W, X, gradient)
%
%

    [d,n] = size(X);

    if gradient
        r = diag(X);
    else
        r = W' * diag(X);
    end
end
