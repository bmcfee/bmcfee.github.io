function Perf = mlr_test(W, test_k, Xtrain, Ytrain, Xtest, Ytest)
%
%   Perf = mlr_test(W, test_k, Xtrain, Ytrain, Xtest, Ytest)
%
%       W       = d-by-d positive semi-definite matrix
%       test_k  = vector of k-values to use for KNN/Prec@k/NDCG
%       Xtrain  = d-by-n matrix of training data
%       Ytrain  = n-by-1 vector of training labels
%                   OR
%                 n-by-2 cell array where
%                   Y{q,1} contains relevant indices (in 1..n) for point q
%                   Y{q,2} contains irrelevant indices (in 1..n) for point q
%       Xtest   = d-by-m matrix of testing data
%       Ytest   = m-by-1 vector of training labels, or m-by-2 cell array 
%               
%
%   The output structure Perf contains the mean score for:
%       AUC, KNN, Prec@k, MAP, MRR, NDCG,
%   as well as the effective dimensionality of W, and
%   the best-performing k-value for KNN, Prec@k, and NDCG.
%

    addpath('cuttingPlane', 'distance', 'feasible', 'initialize', 'loss', ...
            'metricPsi', 'regularize', 'separationOracle', 'util');

    Perf        = struct(                       ...
                            'AUC',      [],     ...
                            'KNN',      [],     ...
                            'PrecAtK',  [],     ...
                            'MAP',      [],     ...
                            'MRR',      [],     ...
                            'NDCG',     [],     ...
                            'dimensionality',   [],     ...
                            'KNNk',     [],     ...
                            'PrecAtKk', [],     ...
                            'NDCGk',    []     ...
                );

    [d, nTrain] = size(Xtrain);
    nTest       = length(Ytest);
    test_k      = min(test_k, nTrain);

    %%%
    % First, compute the distance matrix
    if size(W,2) == d
        D       = setDistanceFull([Xtrain Xtest], W, nTrain + (1:nTest), 1:nTrain);
    else
        D       = setDistanceDiag([Xtrain Xtest], W, nTrain + (1:nTest), 1:nTrain);
    end
    D       = full(D(1:nTrain, nTrain + (1:nTest)));

    % Sort by distance
    [v,I]   = sort(D, 1);

    % Compute label agreement
    if iscell(Ytest)
        Agree   = zeros(nTrain, nTest);
        for i = 1:nTest
            Agree(:,i) = ismember(I(:,i), Ytest{i,1});
        end
    else
        Labels  = Ytrain(I);
        Agree   = bsxfun(@eq, Ytest', Labels); 
    end
    %%% LOSS FUNCTIONS %%%

    % Compute dimension
        if size(W,2) == nTrain
            [v,dim]   = eig(0.5 * (W + W));
            dim       = abs(real(diag(dim)));
        else
            dim       = W;
        end
        cd      = cumsum(dim) / sum(dim);
        Perf.dimensionality  = find(cd >= 0.95, 1);
        if isempty(Perf.dimensionality)
            Perf.dimensionality = 0;
        end
    % Compute mean precision-at-k
    Perf.PrecAtK        = -Inf;
    Perc.PrecAtKk       = 0;
    for k = test_k
        b   = mean( mean( Agree(1:k, :), 1 ) );
        if b > Perf.PrecAtK
            Perf.PrecAtK = b;
            Perf.PrecAtKk = k;
        end
    end

    % Compute mean knn error
    Perf.KNN        = -Inf;
    Perc.KNNk       = 0;

    % This only makes sense if we're in the label case
    if ~iscell(Ytest)
        for k = test_k
            b   = mean( mode( Labels(1:k,:), 1 ) == Ytest');
            if b > Perf.KNN
                Perf.KNN    = b;
                Perf.KNNk   = k;
            end
        end
    end

    % Compute MAP score
        Perf.MAP        = bsxfun(@ldivide, (1:nTrain)', cumsum(Agree, 1));
        Perf.MAP        = mean(sum(Perf.MAP .* Agree, 1)./ sum(Agree, 1));

    % Compute MRR score
        Perf.MRR        = 0;
        for i = 1:nTest
            Perf.MRR    = Perf.MRR  + (1 / find(Agree(:,i), 1));
        end
        Perf.MRR        = Perf.MRR / nTest;


    % Compute AUC score
        TPR             = cumsum(Agree,     1);
        FPR             = cumsum(~Agree,    1);

        numPos          = TPR(end,:);
        numNeg          = FPR(end,:);

        TPR             = mean(bsxfun(@rdivide, TPR, numPos),2);
        FPR             = mean(bsxfun(@rdivide, FPR, numNeg),2);
        Perf.AUC        = diff([0 FPR']) * TPR;


    % Compute NDCG score
        Discount        = zeros(1, nTrain);
        Discount(1:2)   = 1;
    Perf.NDCG   = -Inf;
    Perf.NDCGk  = 0;
    for k = test_k
        
        Discount(3:k)   = 1 ./ log2(3:k);
        Discount        = Discount / sum(Discount);

        b = mean(Discount * Agree);
        if b > Perf.NDCG
            Perf.NDCG = b;
            Perf.NDCGk = k;
        end
    end

end
