function dPsi = cpGradientFull(X, S)

    dPsi    = X * S * X';

end
