function dPsi = cpGradientDiag(X, S)

    dPsi    = diag(X * S * X');

end
