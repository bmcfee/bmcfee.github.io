function unittest()

    % a 10-by-10 psd data/kernel matrix

    X = [   4.9685    4.3950    3.2449    2.1332    3.5775    2.4259    2.8225    3.1015    3.7586    2.2448; ...
            4.3950    5.3439    3.4109    1.9935    3.8431    2.9700    2.7618    3.3252    4.3192    2.7191; ...
            3.2449    3.4109    4.2245    2.7018    3.3708    2.6405    3.5188    3.1046    3.3147    2.6348; ...
            2.1332    1.9935    2.7018    2.7533    2.2067    2.1660    2.1623    2.0348    1.9329    1.0029; ...
            3.5775    3.8431    3.3708    2.2067    3.5203    2.5093    2.6402    2.6720    3.1908    2.1377; ...
            2.4259    2.9700    2.6405    2.1660    2.5093    2.6859    2.1274    2.0036    2.7192    1.4960; ...
            2.8225    2.7618    3.5188    2.1623    2.6402    2.1274    3.4954    2.7986    2.9697    2.3057; ...
            3.1015    3.3252    3.1046    2.0348    2.6720    2.0036    2.7986    3.1851    2.9109    2.0094; ...
            3.7586    4.3192    3.3147    1.9329    3.1908    2.7192    2.9697    2.9109    3.9902    2.6847; ...
            2.2448    2.7191    2.6348    1.0029    2.1377    1.4960    2.3057    2.0094    2.6847    2.4444];
    
    % class label vector
    Yclass = [1 2 3 1 2 3 1 2 3 1]';

    % Relevant/irrelevant set cell array
    Yrel    = { [2 3], [4 5 6 7 8 9 10] ; ...
                [1 3], [4 5 6 7 8 9 10] ; ...
                [1 2], [4 5 6 7 8 9 10] ; ...
                [5 6], [1 2 3 7 8 9 10] ; ...
                [4 6], [1 2 3 7 8 9 10] ; ...
                [4 5], [1 2 3 7 8 9 10] ; ...
                [8 9], [1 2 3 4 5 6 10] ; ...
                [7 9], [1 2 3 4 5 6 10] ; ...
                [7 8], [1 2 3 4 5 6 10] ; ...
                [1 2 3 4 5], [6 7 8 9]};

    % Loss values to test
    LOSS    = {'AUC', 'Prec@k', 'MAP', 'MRR', 'NDCG'};


    % Regularization values to test
    REG = [0,1,2,3];

    % Batch sizes to test
    BATCH = [0 1 5];

    % Diagonal settings
    DIAG = [0 1];

    figure(1);
    for l = 1:length(LOSS)
        display(['Testing ', LOSS{l}]);
        for r = 1:length(REG)
            display(sprintf('\tREG=%d', REG(r)));
            for b = 1:length(BATCH)
                display(sprintf('\tB=%d', BATCH(b)));
                for d = 1:length(DIAG)
                    display(sprintf('\tDiagonal=%d', DIAG(d)));
                    [W, Xi, D] = mlr_train(X, Yrel, 10e5, LOSS{l}, REG(r), DIAG(d), BATCH(b));
                    imagesc(W); drawnow;
                    [W, Xi, D] = mlr_train(X, Yclass, 10e5, LOSS{l}, REG(r), DIAG(d), BATCH(b));
                    imagesc(W); drawnow;
                end
            end
        end
    end

end
